import { useState, useEffect } from 'react';
import { StreamStatus } from '../types';

export const useStreamStatus = (streamId: string) => {
  const [status, setStatus] = useState<StreamStatus>({
    isLive: false,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;
    let intervalId: NodeJS.Timeout | null = null;

    const fetchStreamStatus = async () => {
      if (!streamId) {
        setStatus({
          isLive: false,
          isLoading: false,
          error: 'No stream ID provided'
        });
        return;
      }

      try {
        setStatus(prev => ({ ...prev, isLoading: true, error: null }));

        // Use Supabase Edge Function
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
        
        if (!supabaseUrl || !supabaseAnonKey) {
          throw new Error('Supabase configuration missing. Please connect to Supabase.');
        }

        const functionUrl = `${supabaseUrl}/functions/v1/check-stream-status`;

        // Add timeout to prevent hanging requests
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout

        const response = await fetch(functionUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseAnonKey}`,
          },
          body: JSON.stringify({ streamId }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`Supabase function responded with status: ${response.status}`);
        }

        const data = await response.json();
        
        if (!cancelled) {
          setStatus({
            isLive: data.isLive || false,
            isLoading: false,
            error: data.error || null,
          });
        }
      } catch (error) {
        console.error('Error fetching stream status:', error);
        if (!cancelled) {
          let errorMessage = 'Unable to check stream status';
          
          if (error instanceof Error) {
            if (error.name === 'AbortError') {
              errorMessage = 'Request timed out - please try again';
            } else if (error.message.includes('Failed to fetch')) {
              errorMessage = 'Cannot connect to Supabase. Please check your internet connection.';
            } else if (error.message.includes('Supabase configuration missing')) {
              errorMessage = 'Please connect to Supabase using the button in the top right corner.';
            } else {
              errorMessage = error.message;
            }
          }
          
          setStatus({
            isLive: false,
            isLoading: false,
            error: errorMessage,
          });
        }
      }
    };

    // Initial fetch
    fetchStreamStatus();

    // Set up polling every 30 seconds, but only if we have Supabase configured
    const setupPolling = () => {
      if (import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY) {
        intervalId = setInterval(fetchStreamStatus, 30000);
      }
    };

    // Delay polling setup to avoid immediate repeated errors
    setTimeout(setupPolling, 1000);

    // Cleanup function
    return () => {
      cancelled = true;
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [streamId]);

  return status;
};