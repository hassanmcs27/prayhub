import { useState, useEffect, useRef } from 'react';

interface CountdownReturn {
  hours: number;
  minutes: number;
  seconds: number;
  isActive: boolean;
}

export const useCountdown = (): CountdownReturn => {
  const [timeLeft, setTimeLeft] = useState<CountdownReturn>({
    hours: 0,
    minutes: 0,
    seconds: 0,
    isActive: false
  });
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date();
      const nextHour = new Date();
      nextHour.setHours(now.getHours() + 1, 0, 0, 0);
      
      const difference = nextHour.getTime() - now.getTime();
      
      if (difference > 0) {
        const hours = Math.floor(difference / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        
        setTimeLeft({
          hours,
          minutes,
          seconds,
          isActive: true
        });
      } else {
        setTimeLeft({
          hours: 0,
          minutes: 0,
          seconds: 0,
          isActive: false
        });
      }
    };

    // Clear any existing interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    // Calculate immediately
    calculateTimeLeft();
    
    // Set up new interval
    intervalRef.current = setInterval(calculateTimeLeft, 1000);

    // Cleanup function
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, []); // Empty dependency array to prevent re-running on language changes

  return timeLeft;
};