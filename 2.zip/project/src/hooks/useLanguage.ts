import { useState, useEffect } from 'react';
import { DEFAULT_LANGUAGE } from '../data/languages';
import { TRANSLATIONS } from '../data/translations';

export const useLanguage = () => {
  const [currentLanguage, setCurrentLanguage] = useState<string>(() => {
    // Try to get saved language from localStorage first
    const savedLanguage = localStorage.getItem('prayer-portal-language');
    if (savedLanguage && TRANSLATIONS[savedLanguage]) {
      return savedLanguage;
    }
    
    // Fallback to browser language detection
    const userLanguage = navigator.language.split('-')[0];
    if (TRANSLATIONS[userLanguage]) {
      return userLanguage;
    }
    
    return DEFAULT_LANGUAGE;
  });

  // Save language preference to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('prayer-portal-language', currentLanguage);
    // Force a small delay to ensure state updates propagate
    setTimeout(() => {
      // This ensures all components re-render with new language
    }, 0);
  }, [currentLanguage]);

  const t = (key: string, params?: Record<string, string | number>): string => {
    let translation = TRANSLATIONS[currentLanguage]?.[key] || TRANSLATIONS[DEFAULT_LANGUAGE]?.[key] || key;
    
    if (params) {
      Object.entries(params).forEach(([param, value]) => {
        translation = translation.replace(`{${param}}`, String(value));
      });
    }
    
    return translation;
  };

  const changeLanguage = (languageCode: string) => {
    if (languageCode !== currentLanguage && TRANSLATIONS[languageCode]) {
      setCurrentLanguage(languageCode);
    }
  };

  return {
    currentLanguage,
    setCurrentLanguage: changeLanguage,
    t
  };
};