export interface Prayer {
  id: string;
  name: string;
  description: string;
  duration: number; // in minutes
  videoId?: string; // YouTube video ID (for recorded content)
  streamKey?: string; // Stream key for live content
  channelId?: string; // YouTube channel ID
  streamId?: string; // Stream ID for checking live status
}

export interface Language {
  code: string;
  name: string;
  flag: string;
}

export interface Translation {
  [key: string]: string;
}

export interface Translations {
  [languageCode: string]: Translation;
}

export interface StreamConfig {
  isLive: boolean;
  streamKey?: string;
  channelId?: string;
  rtmpUrl?: string;
}

export interface StreamStatus {
  isLive: boolean;
  isLoading: boolean;
  error: string | null;
}