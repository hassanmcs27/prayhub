import React from 'react';
import { PrayerCard } from './PrayerCard';
import { PRAYERS } from '../data/prayers';
import { useLanguage } from '../hooks/useLanguage';

export const PrayersSection: React.FC = () => {
  const { t } = useLanguage();

  // Generate next prayer times (for demo purposes)
  const getNextPrayerTime = (index: number) => {
    const now = new Date();
    const nextHour = new Date();
    nextHour.setHours(now.getHours() + 1 + (index % 3), 0, 0, 0);
    return nextHour.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <section id="prayers" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            {t('prayers.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('prayers.subtitle')}
          </p>
        </div>
        
        <div className="flex justify-center">
          <div className="w-full max-w-md">
          {PRAYERS.map((prayer, index) => (
            <PrayerCard
              key={prayer.id}
              prayer={prayer}
              nextTime={getNextPrayerTime(index)}
            />
          ))}
          </div>
        </div>
      </div>
    </section>
  );
};