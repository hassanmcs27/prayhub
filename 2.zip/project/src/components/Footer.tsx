import React from 'react';
import { Heart, Mail, Globe, Shield } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-gray-800 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Logo & Mission */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-gray-700 p-2 rounded-full">
                <Heart className="h-6 w-6 text-white" fill="currentColor" />
              </div>
              <span className="text-2xl font-bold">Prayer Portal</span>
            </div>
            <p className="text-gray-300 leading-relaxed text-lg mb-6">
              {t('footer.mission')}
            </p>
            <div className="flex space-x-4">
              <div className="bg-gray-700 p-3 rounded-full hover:bg-gray-600 transition-colors cursor-pointer">
                <Globe className="h-5 w-5" />
              </div>
              <div className="bg-gray-700 p-3 rounded-full hover:bg-gray-600 transition-colors cursor-pointer">
                <Mail className="h-5 w-5" />
              </div>
              <div className="bg-gray-700 p-3 rounded-full hover:bg-gray-600 transition-colors cursor-pointer">
                <Heart className="h-5 w-5" />
              </div>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <a href="#home" className="text-gray-300 hover:text-white transition-colors">
                  {t('nav.home')}
                </a>
              </li>
              <li>
                <a href="#prayers" className="text-gray-300 hover:text-white transition-colors">
                  {t('nav.prayers')}
                </a>
              </li>
              <li>
                <a href="#donate" className="text-gray-300 hover:text-white transition-colors">
                  {t('nav.donate')}
                </a>
              </li>
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Legal</h3>
            <ul className="space-y-3">
              <li>
                <a href="#contact" className="text-gray-300 hover:text-white transition-colors flex items-center space-x-2">
                  <Mail size={16} />
                  <span>{t('footer.contact')}</span>
                </a>
              </li>
              <li>
                <a href="#privacy" className="text-gray-300 hover:text-white transition-colors flex items-center space-x-2">
                  <Shield size={16} />
                  <span>{t('footer.privacy')}</span>
                </a>
              </li>
              <li>
                <a href="#terms" className="text-gray-300 hover:text-white transition-colors">
                  {t('footer.terms')}
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Prayer Portal. All rights reserved. Made with ❤️ for the global faith community.
          </p>
        </div>
      </div>
    </footer>
  );
};