import React from 'react';
import { Clock, Play, Radio, AlertCircle } from 'lucide-react';
import { Prayer } from '../types';
import { useLanguage } from '../hooks/useLanguage';
import { useStreamStatus } from '../hooks/useStreamStatus';

interface PrayerCardProps {
  prayer: Prayer;
  nextTime: string;
}

export const PrayerCard: React.FC<PrayerCardProps> = ({ prayer, nextTime }) => {
  const { t } = useLanguage();
  const { isLive, isLoading, error } = useStreamStatus(prayer.streamId || '');

  const handleJoinPrayer = () => {
    if (!isLive) {
      return; // Don't open anything if stream is not live
    }

    // Use the YouTube channel ID from environment variables
    const YOUTUBE_CHANNEL_ID = import.meta.env.VITE_YOUTUBE_CHANNEL_ID || 'UC3yKVPf7L6mMzHD1dr-thOA';
    
    // Open the live stream URL - you can customize this URL format based on your streaming platform
    const liveStreamUrl = `https://www.youtube.com/channel/${YOUTUBE_CHANNEL_ID}/live`;
    
    // Open in a new tab
    window.open(liveStreamUrl, '_blank', 'noopener,noreferrer');
  };

  const getButtonContent = () => {
    if (isLoading) {
      return (
        <>
          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          <span>Checking...</span>
        </>
      );
    }

    if (error) {
      return (
        <>
          <AlertCircle size={18} />
          <span>Status Unknown</span>
        </>
      );
    }

    if (isLive) {
      return (
        <>
          <Radio size={18} className="animate-pulse" />
          <span>{t('prayer.joinLive')}</span>
        </>
      );
    }

    return (
      <>
        <Play size={18} fill="currentColor" />
        <span>{t('prayer.notLive')}</span>
      </>
    );
  };

  const getButtonStyles = () => {
    if (isLoading) {
      return 'bg-gray-400 cursor-wait';
    }

    if (error) {
      return 'bg-orange-500 hover:bg-orange-600 cursor-default';
    }

    if (isLive) {
      return 'bg-red-600 hover:bg-red-700 cursor-pointer transform hover:scale-105 animate-pulse';
    }

    return 'bg-gray-400 cursor-not-allowed';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group flex flex-col h-full border border-gray-100">
      <div className="h-64 bg-gradient-to-br from-gray-50 to-gray-100 relative overflow-hidden flex items-center justify-center">
        {/* Live indicator */}
        {isLive && (
          <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1 animate-pulse">
            <Radio size={12} />
            <span>LIVE</span>
          </div>
        )}
        
        <div className="text-center p-6">
          <div className={`backdrop-blur-sm rounded-full p-4 mb-4 mx-auto w-16 h-16 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 ${
            isLive ? 'bg-red-100/80' : 'bg-white/80'
          }`}>
            {isLive ? (
              <Radio className="h-8 w-8 text-red-600 animate-pulse" />
            ) : (
              <Play className="h-8 w-8 text-gray-600" fill="currentColor" />
            )}
          </div>
          <h3 className="text-gray-800 font-bold text-2xl mb-3 group-hover:scale-105 transition-transform duration-300">
            {prayer.name}
          </h3>
          <div className="flex items-center justify-center text-gray-600 text-base space-x-4">
            <div className="flex items-center space-x-1">
              <Clock size={18} />
              <span>{t('prayers.duration', { duration: prayer.duration })}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="p-8 flex flex-col flex-grow">
        <p className="text-gray-600 leading-relaxed mb-8 flex-grow text-lg">
          {prayer.description}
        </p>
        <button 
          onClick={handleJoinPrayer}
          disabled={!isLive || isLoading}
          className={`w-full text-white py-4 px-8 rounded-lg font-semibold transition-all duration-200 mt-auto flex items-center justify-center space-x-2 text-lg ${getButtonStyles()}`}
        >
          {getButtonContent()}
        </button>
        
        {!isLive && !isLoading && !error && (
          <p className="text-center text-base text-gray-500 mt-3">
            {t('prayer.waitingForLive')}
          </p>
        )}
      </div>
    </div>
  );
};