 import React from 'react';
 import { Globe } from 'lucide-react';
 import { LANGUAGES } from '../data/languages';
 import { useLanguage } from '../hooks/useLanguage';

 export const LanguageSelector: React.FC = () => {
   const { currentLanguage, setCurrentLanguage } = useLanguage();

   const handleLanguageChange = (languageCode: string) => {
     setCurrentLanguage(languageCode);
     window.location.reload();
   };

   return (
     <div className="relative group">
       <button className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-all duration-200">
         <Globe size={18} className="text-gray-600" />
         <span className="text-gray-800 font-medium">
           {LANGUAGES.find(lang => lang.code === currentLanguage)?.flag}
         </span>
       </button>
       
       <div className="absolute right-0 top-full mt-2 bg-white backdrop-blur-sm rounded-lg shadow-lg py-2 min-w-[150px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 border border-gray-100">
         {LANGUAGES.map((language) => (
           <button
             key={language.code}
             onClick={(e) => {
               e.preventDefault();
               handleLanguageChange(language.code);
             }}
             className={`w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors duration-150 flex items-center space-x-3 ${
               currentLanguage === language.code ? 'bg-gray-50' : ''
             }`}
           >
             <span className="text-lg">{language.flag}</span>
             <span className="text-gray-800 font-medium">{language.name}</span>
           </button>
         ))}
       </div>
     </div>
   );
 };
