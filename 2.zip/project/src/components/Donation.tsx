import React from 'react';
import { Heart, CreditCard, Building } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';

export const Donation: React.FC = () => {
  const { t } = useLanguage();

  const donationMethods = [
    {
      icon: CreditCard,
      title: t('donate.paypal'),
      description: 'Quick and secure donations via PayPal',
      color: 'bg-gray-600 hover:bg-gray-700',
      link: '#paypal'
    },
    {
      icon: Building,
      title: t('donate.bank'),
      description: 'Direct bank transfer for larger donations',
      color: 'bg-gray-500 hover:bg-gray-600',
      link: '#bank'
    }
  ];

  return (
    <section id="donate" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="bg-gray-100 w-20 h-20 rounded-full flex items-center justify-center mb-6 mx-auto">
            <Heart className="h-10 w-10 text-gray-600" fill="currentColor" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            {t('donate.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            {t('donate.subtitle')}
          </p>
          <p className="text-lg text-gray-500 max-w-4xl mx-auto leading-relaxed">
            {t('donate.text')}
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {donationMethods.map((method, index) => (
            <div key={index} className="bg-gray-50 rounded-2xl p-8 shadow-sm hover:shadow-md transition-all duration-300 group border border-gray-100">
              <div className={`${method.color} w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-300`}>
                <method.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">
                {method.title}
              </h3>
              <p className="text-gray-600 text-center mb-6">
                {method.description}
              </p>
              <button className={`w-full ${method.color} text-white py-3 px-6 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105`}>
                {t('donate.cta')}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};