import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { PrayersSection } from './components/PrayersSection';
import { Donation } from './components/Donation';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <About />
        <PrayersSection />
        <Donation />
      </main>
      <Footer />
    </div>
  );
}

export default App;