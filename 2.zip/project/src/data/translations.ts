import { Translations } from '../types';

export const TRANSLATIONS: Translations = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.prayers': 'Prayers',
    'nav.schedule': 'Schedule',
    'nav.donate': 'Donate',
    
    // Hero Section
    'hero.title': 'Unite in Prayer',
    'hero.subtitle': 'Join believers worldwide in synchronized prayer sessions every hour',
    'hero.description': 'Experience the power of collective prayer as people from every corner of the earth come together at predetermined times to lift their hearts to God.',
    'hero.cta': 'Join Next Prayer',
    
    // Prayer Status
    'prayer.live': 'Prayer Live Now',
    'prayer.offline': 'Stream Offline',
    'prayer.next': 'Next Prayer in',
    'prayer.current': 'Current Prayer',
    'prayer.join': 'Join Prayer',
    'prayer.joinLive': 'Join Live Prayer',
    'prayer.notLive': 'Prayer Not Live',
    'prayer.waitingForLive': 'Waiting for live stream...',
    'prayer.watch': 'Watch on YouTube',
    'prayer.watchLive': 'Watch Live',
    'prayer.nextLive': 'Stream will be live during scheduled prayer times',
    'prayer.scheduleInfo': 'Check back at the top of each hour for live prayer sessions',
    
    // About Section
    'about.title': 'A Global Community of Prayer',
    'about.text1': 'Every hour, believers from around the world unite in prayer, creating a continuous chain of worship that spans all time zones.',
    'about.text2': 'Join thousands of faithful souls in these sacred moments of connection with the Divine.',
    'about.text3': 'Together, we strengthen our faith and lift each other up in prayer.',
    
    // Prayers Section
    'prayers.title': 'Live Prayer Stream',
    'prayers.subtitle': 'Join us in prayer with believers from around the world',
    'prayers.duration': 'Duration: {duration} minutes',
    'prayers.next': 'Next at {time}',
    
    // About Features
    'about.feature1.title': 'Global Unity',
    'about.feature2.title': 'Faithful Community',
    'about.feature3.title': 'Spiritual Growth',
    
    // Donation Section
    'donate.title': 'Support Our Mission',
    'donate.subtitle': 'Help us continue bringing people together in prayer',
    'donate.text': 'Your generous donations help us maintain our prayer streams, website, and reach believers worldwide.',
    'donate.cta': 'Donate Now',
    'donate.paypal': 'PayPal',
    'donate.bank': 'Bank Transfer',
    
    // Footer
    'footer.mission': 'Uniting hearts in prayer across the globe',
    'footer.contact': 'Contact Us',
    'footer.privacy': 'Privacy Policy',
    'footer.terms': 'Terms of Service',
    
    // Time
    'time.hours': 'hours',
    'time.minutes': 'minutes',
    'time.seconds': 'seconds',
  },
  
  pl: {
    // Navigation
    'nav.home': 'Strona główna',
    'nav.prayers': 'Modlitwy',
    'nav.schedule': 'Harmonogram',
    'nav.donate': 'Darowizna',
    
    // Hero Section
    'hero.title': 'Zjednoczeni w Modlitwie',
    'hero.subtitle': 'Dołącz do wiernych na całym świecie w zsynchronizowanych sesjach modlitewnych co godzinę',
    'hero.description': 'Doświadcz mocy wspólnej modlitwy, gdy ludzie z każdego zakątka ziemi zbierają się w określonych czasach, aby podnieść swoje serca do Boga.',
    'hero.cta': 'Dołącz do następnej modlitwy',
    
    // Prayer Status
    'prayer.live': 'Modlitwa na żywo',
    'prayer.offline': 'Transmisja offline',
    'prayer.next': 'Następna modlitwa za',
    'prayer.current': 'Aktualna modlitwa',
    'prayer.join': 'Dołącz do modlitwy',
    'prayer.joinLive': 'Dołącz do modlitwy na żywo',
    'prayer.notLive': 'Modlitwa nie jest na żywo',
    'prayer.waitingForLive': 'Oczekiwanie na transmisję na żywo...',
    'prayer.watch': 'Oglądaj na YouTube',
    'prayer.watchLive': 'Oglądaj na żywo',
    'prayer.nextLive': 'Transmisja będzie dostępna podczas zaplanowanych modlitw',
    'prayer.scheduleInfo': 'Sprawdź ponownie na początku każdej godziny dla sesji modlitewnych na żywo',
    
    // About Section
    'about.title': 'Globalna Wspólnota Modlitwy',
    'about.text1': 'Co godzinę wierni z całego świata jednoczą się w modlitwie, tworząc ciągły łańcuch uwielbienia obejmujący wszystkie strefy czasowe.',
    'about.text2': 'Dołącz do tysięcy wiernych dusz w tych świętych chwilach połączenia z Boskością.',
    'about.text3': 'Razem wzmacniamy naszą wiarę i podnosimy się nawzajem w modlitwie.',
    
    // Prayers Section
    'prayers.title': 'Transmisja Modlitwy na Żywo',
    'prayers.subtitle': 'Dołącz do nas w modlitwie z wiernymi z całego świata',
    'prayers.duration': 'Czas trwania: {duration} minut',
    'prayers.next': 'Następna o {time}',
    
    // About Features
    'about.feature1.title': 'Globalna Jedność',
    'about.feature2.title': 'Wspólnota Wiernych',
    'about.feature3.title': 'Duchowy Rozwój',
    
    // Donation Section
    'donate.title': 'Wspomóż naszą misję',
    'donate.subtitle': 'Pomóż nam nadal łączyć ludzi w modlitwie',
    'donate.text': 'Wasze hojne darowizny pomagają nam utrzymywać nasze transmisje modlitewne, stronę internetową i docierać do wiernych na całym świecie.',
    'donate.cta': 'Przekaż darowiznę',
    'donate.paypal': 'PayPal',
    'donate.bank': 'Przelew bankowy',
    
    // Footer
    'footer.mission': 'Łączymy serca w modlitwie na całym świecie',
    'footer.contact': 'Kontakt',
    'footer.privacy': 'Polityka prywatności',
    'footer.terms': 'Regulamin',
    
    // Time
    'time.hours': 'godzin',
    'time.minutes': 'minut',
    'time.seconds': 'sekund',
  },
  
  es: {
    // Navigation
    'nav.home': 'Inicio',
    'nav.prayers': 'Oraciones',
    'nav.schedule': 'Horario',
    'nav.donate': 'Donar',
    
    // Hero Section
    'hero.title': 'Unidos en Oración',
    'hero.subtitle': 'Únete a creyentes de todo el mundo en sesiones de oración sincronizadas cada hora',
    'hero.description': 'Experimenta el poder de la oración colectiva mientras personas de cada rincón de la tierra se reúnen en momentos predeterminados para elevar sus corazones a Dios.',
    'hero.cta': 'Únete a la próxima oración',
    
    // Prayer Status
    'prayer.live': 'Oración en vivo',
    'prayer.offline': 'Transmisión fuera de línea',
    'prayer.next': 'Próxima oración en',
    'prayer.current': 'Oración actual',
    'prayer.join': 'Únete a la oración',
    'prayer.joinLive': 'Únete a la oración en vivo',
    'prayer.notLive': 'Oración no está en vivo',
    'prayer.waitingForLive': 'Esperando transmisión en vivo...',
    'prayer.watch': 'Ver en YouTube',
    'prayer.watchLive': 'Ver en vivo',
    'prayer.nextLive': 'La transmisión estará en vivo durante los horarios de oración programados',
    'prayer.scheduleInfo': 'Regresa al inicio de cada hora para sesiones de oración en vivo',
    
    // About Section
    'about.title': 'Una Comunidad Global de Oración',
    'about.text1': 'Cada hora, creyentes de todo el mundo se unen en oración, creando una cadena continua de adoración que abarca todas las zonas horarias.',
    'about.text2': 'Únete a miles de almas fieles en estos sagrados momentos de conexión con lo Divino.',
    'about.text3': 'Juntos, fortalecemos nuestra fe y nos elevamos mutuamente en oración.',
    
    // Prayers Section
    'prayers.title': 'Transmisión de Oración en Vivo',
    'prayers.subtitle': 'Únete a nosotros en oración con creyentes de todo el mundo',
    'prayers.duration': 'Duración: {duration} minutos',
    'prayers.next': 'Próxima a las {time}',
    
    // About Features
    'about.feature1.title': 'Unidad Global',
    'about.feature2.title': 'Comunidad Fiel',
    'about.feature3.title': 'Crecimiento Espiritual',
    
    // Donation Section
    'donate.title': 'Apoya nuestra misión',
    'donate.subtitle': 'Ayúdanos a continuar uniendo personas en oración',
    'donate.text': 'Tus generosas donaciones nos ayudan a mantener nuestras transmisiones de oración, sitio web y llegar a creyentes en todo el mundo.',
    'donate.cta': 'Donar ahora',
    'donate.paypal': 'PayPal',
    'donate.bank': 'Transferencia bancaria',
    
    // Footer
    'footer.mission': 'Uniendo corazones en oración en todo el mundo',
    'footer.contact': 'Contáctanos',
    'footer.privacy': 'Política de privacidad',
    'footer.terms': 'Términos de servicio',
    
    // Time
    'time.hours': 'horas',
    'time.minutes': 'minutos',
    'time.seconds': 'segundos',
  },
  
  pt: {
    // Navigation
    'nav.home': 'Início',
    'nav.prayers': 'Orações',
    'nav.schedule': 'Cronograma',
    'nav.donate': 'Doar',
    
    // Hero Section
    'hero.title': 'Unidos em Oração',
    'hero.subtitle': 'Junte-se a fiéis do mundo todo em sessões de oração sincronizadas a cada hora',
    'hero.description': 'Experimente o poder da oração coletiva quando pessoas de todos os cantos da terra se reúnem em momentos predeterminados para elevar seus corações a Deus.',
    'hero.cta': 'Junte-se à próxima oração',
    
    // Prayer Status
    'prayer.live': 'Oração ao vivo',
    'prayer.offline': 'Transmissão offline',
    'prayer.next': 'Próxima oração em',
    'prayer.current': 'Oração atual',
    'prayer.join': 'Junte-se à oração',
    'prayer.joinLive': 'Junte-se à oração ao vivo',
    'prayer.notLive': 'Oração não está ao vivo',
    'prayer.waitingForLive': 'Aguardando transmissão ao vivo...',
    'prayer.watch': 'Assista no YouTube',
    'prayer.watchLive': 'Assista ao vivo',
    'prayer.nextLive': 'A transmissão estará ao vivo durante os horários de oração programados',
    'prayer.scheduleInfo': 'Volte no início de cada hora para sessões de oração ao vivo',
    
    // About Section
    'about.title': 'Uma Comunidade Global de Oração',
    'about.text1': 'A cada hora, fiéis de todo o mundo se unem em oração, criando uma cadeia contínua de adoração que abrange todos os fusos horários.',
    'about.text2': 'Junte-se a milhares de almas fiéis nestes momentos sagrados de conexão com o Divino.',
    'about.text3': 'Juntos, fortalecemos nossa fé e nos elevamos mutuamente em oração.',
    
    // Prayers Section
    'prayers.title': 'Transmissão de Oração ao Vivo',
    'prayers.subtitle': 'Junte-se a nós em oração com fiéis de todo o mundo',
    'prayers.duration': 'Duração: {duration} minutos',
    'prayers.next': 'Próxima às {time}',
    
    // About Features
    'about.feature1.title': 'Unidade Global',
    'about.feature2.title': 'Comunidade Fiel',
    'about.feature3.title': 'Crescimento Espiritual',
    
    // Donation Section
    'donate.title': 'Apoie nossa missão',
    'donate.subtitle': 'Ajude-nos a continuar unindo pessoas em oração',
    'donate.text': 'Suas doações generosas nos ajudam a manter nossas transmissões de oração, site e alcançar fiéis ao redor do mundo.',
    'donate.cta': 'Doar agora',
    'donate.paypal': 'PayPal',
    'donate.bank': 'Transferência bancária',
    
    // Footer
    'footer.mission': 'Unindo corações em oração ao redor do mundo',
    'footer.contact': 'Entre em contato',
    'footer.privacy': 'Política de privacidade',
    'footer.terms': 'Termos de serviço',
    
    // Time
    'time.hours': 'horas',
    'time.minutes': 'minutos',
    'time.seconds': 'segundos',
  },
  
  fr: {
    // Navigation
    'nav.home': 'Accueil',
    'nav.prayers': 'Prières',
    'nav.schedule': 'Horaire',
    'nav.donate': 'Faire un don',
    
    // Hero Section
    'hero.title': 'Unis dans la Prière',
    'hero.subtitle': 'Rejoignez des croyants du monde entier dans des sessions de prière synchronisées chaque heure',
    'hero.description': 'Expérimentez la puissance de la prière collective alors que des personnes de tous les coins de la terre se rassemblent à des moments prédéterminés pour élever leurs cœurs vers Dieu.',
    'hero.cta': 'Rejoindre la prochaine prière',
    
    // Prayer Status
    'prayer.live': 'Prière en direct',
    'prayer.offline': 'Diffusion hors ligne',
    'prayer.next': 'Prochaine prière dans',
    'prayer.current': 'Prière actuelle',
    'prayer.join': 'Rejoindre la prière',
    'prayer.joinLive': 'Rejoindre la prière en direct',
    'prayer.notLive': 'Prière pas en direct',
    'prayer.waitingForLive': 'En attente de diffusion en direct...',
    'prayer.watch': 'Regarder sur YouTube',
    'prayer.watchLive': 'Regarder en direct',
    'prayer.nextLive': 'La diffusion sera en direct pendant les heures de prière programmées',
    'prayer.scheduleInfo': 'Revenez au début de chaque heure pour les sessions de prière en direct',
    
    // About Section
    'about.title': 'Une Communauté Mondiale de Prière',
    'about.text1': 'Chaque heure, des croyants du monde entier s\'unissent dans la prière, créant une chaîne continue d\'adoration qui s\'étend sur tous les fuseaux horaires.',
    'about.text2': 'Rejoignez des milliers d\'âmes fidèles dans ces moments sacrés de connexion avec le Divin.',
    'about.text3': 'Ensemble, nous renforçons notre foi et nous nous élevons mutuellement dans la prière.',
    
    // Prayers Section
    'prayers.title': 'Diffusion de Prière en Direct',
    'prayers.subtitle': 'Rejoignez-nous en prière avec des croyants du monde entier',
    'prayers.duration': 'Durée: {duration} minutes',
    'prayers.next': 'Prochaine à {time}',
    
    // About Features
    'about.feature1.title': 'Unité Mondiale',
    'about.feature2.title': 'Communauté Fidèle',
    'about.feature3.title': 'Croissance Spirituelle',
    
    // Donation Section
    'donate.title': 'Soutenez notre mission',
    'donate.subtitle': 'Aidez-nous à continuer à rassembler les gens dans la prière',
    'donate.text': 'Vos dons généreux nous aident à maintenir nos diffusions de prière, notre site web et à atteindre les croyants du monde entier.',
    'donate.cta': 'Faire un don maintenant',
    'donate.paypal': 'PayPal',
    'donate.bank': 'Virement bancaire',
    
    // Footer
    'footer.mission': 'Unir les cœurs dans la prière à travers le monde',
    'footer.contact': 'Nous contacter',
    'footer.privacy': 'Politique de confidentialité',
    'footer.terms': 'Conditions de service',
    
    // Time
    'time.hours': 'heures',
    'time.minutes': 'minutes',
    'time.seconds': 'secondes',
  },
  
  de: {
    // Navigation
    'nav.home': 'Startseite',
    'nav.prayers': 'Gebete',
    'nav.schedule': 'Zeitplan',
    'nav.donate': 'Spenden',
    
    // Hero Section
    'hero.title': 'Vereint im Gebet',
    'hero.subtitle': 'Schließen Sie sich Gläubigen weltweit in synchronisierten Gebetssitzungen jede Stunde an',
    'hero.description': 'Erleben Sie die Kraft des gemeinsamen Gebets, wenn Menschen aus allen Ecken der Erde zu vorbestimmten Zeiten zusammenkommen, um ihre Herzen zu Gott zu erheben.',
    'hero.cta': 'Nächstes Gebet beitreten',
    
    // Prayer Status
    'prayer.live': 'Gebet live',
    'prayer.offline': 'Stream offline',
    'prayer.next': 'Nächstes Gebet in',
    'prayer.current': 'Aktuelles Gebet',
    'prayer.join': 'Gebet beitreten',
    'prayer.joinLive': 'Live-Gebet beitreten',
    'prayer.notLive': 'Gebet nicht live',
    'prayer.waitingForLive': 'Warten auf Live-Übertragung...',
    'prayer.watch': 'Auf YouTube ansehen',
    'prayer.watchLive': 'Live ansehen',
    'prayer.nextLive': 'Der Stream wird während der geplanten Gebetszeiten live sein',
    'prayer.scheduleInfo': 'Schauen Sie zu Beginn jeder Stunde für Live-Gebetssitzungen vorbei',
    
    // About Section
    'about.title': 'Eine Globale Gebetsgemeinschaft',
    'about.text1': 'Jede Stunde vereinen sich Gläubige aus der ganzen Welt im Gebet und schaffen eine kontinuierliche Kette der Anbetung, die alle Zeitzonen umspannt.',
    'about.text2': 'Schließen Sie sich Tausenden von treuen Seelen in diesen heiligen Momenten der Verbindung mit dem Göttlichen an.',
    'about.text3': 'Gemeinsam stärken wir unseren Glauben und erheben uns gegenseitig im Gebet.',
    
    // Prayers Section
    'prayers.title': 'Live-Gebetsübertragung',
    'prayers.subtitle': 'Schließen Sie sich uns im Gebet mit Gläubigen aus der ganzen Welt an',
    'prayers.duration': 'Dauer: {duration} Minuten',
    'prayers.next': 'Nächstes um {time}',
    
    // About Features
    'about.feature1.title': 'Globale Einheit',
    'about.feature2.title': 'Gläubige Gemeinschaft',
    'about.feature3.title': 'Spirituelles Wachstum',
    
    // Donation Section
    'donate.title': 'Unterstützen Sie unsere Mission',
    'donate.subtitle': 'Helfen Sie uns, Menschen weiterhin im Gebet zu vereinen',
    'donate.text': 'Ihre großzügigen Spenden helfen uns, unsere Gebetsübertragungen, Website zu unterhalten und Gläubige weltweit zu erreichen.',
    'donate.cta': 'Jetzt spenden',
    'donate.paypal': 'PayPal',
    'donate.bank': 'Banküberweisung',
    
    // Footer
    'footer.mission': 'Herzen im Gebet weltweit vereinen',
    'footer.contact': 'Kontakt',
    'footer.privacy': 'Datenschutz',
    'footer.terms': 'Nutzungsbedingungen',
    
    // Time
    'time.hours': 'Stunden',
    'time.minutes': 'Minuten',
    'time.seconds': 'Sekunden',
  }
};