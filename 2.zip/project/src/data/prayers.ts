import { Prayer } from '../types';

export const PRAYERS: Prayer[] = [
  {
    id: 'divine-mercy',
    name: 'Chaplet of Divine Mercy',
    description: 'A powerful prayer to Jesus Christ, asking for His mercy upon us and the whole world.',
    duration: 20,
    videoId: 'chaplet-divine-mercy',
    streamId: '3yKVPf7L6mMzHD1dr-thOA1751892595694399'
  }
];