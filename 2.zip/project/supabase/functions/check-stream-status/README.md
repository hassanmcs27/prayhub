# Check Stream Status Edge Function

This Supabase Edge Function checks the live status of YouTube streams using the YouTube Data API.

## Setup

1. **Set Environment Variables**:
   In your Supabase dashboard, go to Settings > Edge Functions and add:
   ```
   YOUTUBE_API_KEY=your_youtube_data_api_key_here
   ```

2. **Get YouTube Data API Key**:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select an existing one
   - Enable the YouTube Data API v3
   - Create credentials (API Key)
   - Restrict the API key to YouTube Data API v3 for security

## Usage

The function accepts POST requests with the following body:
```json
{
  "streamId": "your_youtube_stream_id"
}
```

Returns:
```json
{
  "isLive": true,
  "details": {
    "ingestionStatus": "active",
    "broadcastStatus": "live"
  }
}
```

## Error Handling

The function handles various error cases:
- Missing or invalid stream ID
- YouTube API errors
- Network issues
- Missing API key configuration

## Security

- API key is stored securely as an environment variable
- CORS headers are properly configured
- No sensitive data is exposed to the client