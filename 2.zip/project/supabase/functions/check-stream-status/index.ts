import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

interface StreamStatusRequest {
  streamId: string
}

interface StreamStatusResponse {
  isLive: boolean
  error?: string
  details?: {
    ingestionStatus: string
    broadcastStatus: string
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get YouTube API key from environment variables
    const YOUTUBE_API_KEY = Deno.env.get('YOUTUBE_API_KEY')
    if (!YOUTUBE_API_KEY) {
      throw new Error('YouTube API key not configured')
    }

    // Parse request body
    const { streamId }: StreamStatusRequest = await req.json()
    if (!streamId) {
      throw new Error('streamId is required')
    }

    console.log(`Checking status for stream ID: ${streamId}`)

    // Check ingestion status
    const streamResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/liveStreams?part=status&id=${streamId}&key=${YOUTUBE_API_KEY}`
    )

    if (!streamResponse.ok) {
      throw new Error(`YouTube API error: ${streamResponse.status} ${streamResponse.statusText}`)
    }

    const streamData = await streamResponse.json()
    const streamItems = streamData.items || []
    
    if (streamItems.length === 0) {
      return new Response(
        JSON.stringify({
          isLive: false,
          error: 'Stream ID not found',
          details: {
            ingestionStatus: 'unknown_stream_id',
            broadcastStatus: 'no_stream'
          }
        } as StreamStatusResponse),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    const ingestionStatus = streamItems[0]?.status?.streamStatus || 'unknown'
    console.log(`Ingestion status: ${ingestionStatus}`)

    // Check broadcast lifecycle status
    // Note: This requires OAuth authentication for accessing user's broadcasts
    // For now, we'll determine live status based on ingestion status
    // You can extend this later with proper OAuth flow if needed
    
    let broadcastStatus = 'unknown'
    let isLive = false

    // Determine if stream is live based on ingestion status
    if (ingestionStatus.toLowerCase() === 'active') {
      isLive = true
      broadcastStatus = 'live'
    } else if (ingestionStatus.toLowerCase() === 'inactive') {
      isLive = false
      broadcastStatus = 'ready'
    } else {
      isLive = false
      broadcastStatus = ingestionStatus
    }

    console.log(`Final status - isLive: ${isLive}, ingestion: ${ingestionStatus}, broadcast: ${broadcastStatus}`)

    const response: StreamStatusResponse = {
      isLive,
      details: {
        ingestionStatus,
        broadcastStatus
      }
    }

    return new Response(
      JSON.stringify(response),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error checking stream status:', error)
    
    const errorResponse: StreamStatusResponse = {
      isLive: false,
      error: error.message || 'Unknown error occurred'
    }

    return new Response(
      JSON.stringify(errorResponse),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})