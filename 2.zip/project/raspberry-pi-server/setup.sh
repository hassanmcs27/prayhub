#!/bin/bash

# Raspberry Pi YouTube API Server Setup Script

echo "Setting up YouTube API Server on Raspberry Pi..."

# Update system
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python 3 and pip if not already installed
echo "Installing Python 3 and pip..."
sudo apt install -y python3 python3-pip python3-venv

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv youtube_api_env
source youtube_api_env/bin/activate

# Install Python dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Create systemd service file
echo "Creating systemd service..."
sudo tee /etc/systemd/system/youtube-api.service > /dev/null <<EOF
[Unit]
Description=YouTube Stream Status API
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=$(pwd)
Environment=PATH=$(pwd)/youtube_api_env/bin
ExecStart=$(pwd)/youtube_api_env/bin/python app.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start the service
echo "Enabling and starting the service..."
sudo systemctl daemon-reload
sudo systemctl enable youtube-api.service

echo "Setup complete!"
echo ""
echo "Next steps:"
echo "1. Place your token.json file in this directory"
echo "2. Place your broadcasts.json file in this directory"
echo "3. Start the service: sudo systemctl start youtube-api"
echo "4. Check status: sudo systemctl status youtube-api"
echo "5. View logs: sudo journalctl -u youtube-api -f"
echo ""
echo "The API will be available at: http://your-pi-ip:5000"