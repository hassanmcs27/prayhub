import os
import sys
import json
import logging
import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

# ---------------- Configure Logging ----------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
    force=True
)

# ---------------- Configuration ----------------
SCOPES = [
    'https://www.googleapis.com/auth/youtube',
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.force-ssl'
]
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TOKEN_PATH = os.path.join(BASE_DIR, 'token.json')
CONFIG_PATH = os.path.join(BASE_DIR, 'broadcasts.json')

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Global YouTube service instance
youtube_service = None

def load_broadcasts(json_path):
    """Load list of dicts with 'title' and 'stream_id'."""
    try:
        with open(json_path, 'r') as f:
            data = json.load(f)
        broadcasts = {item.get('stream_id'): item.get('title') for item in data if item.get('stream_id')}
        logging.info("Loaded %d broadcasts from %s", len(broadcasts), json_path)
        return broadcasts
    except Exception as e:
        logging.error("Failed to load broadcasts JSON: %s", e)
        return {}

def get_authenticated_service():
    """Get authenticated YouTube service."""
    global youtube_service
    
    if youtube_service is not None:
        return youtube_service
    
    if not os.path.isfile(TOKEN_PATH):
        logging.error("Configuration error: token.json not found at %s", TOKEN_PATH)
        return None
    
    try:
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)
        if creds.expiry:
            logging.info("Token expires at (UTC): %s", creds.expiry)
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            with open(TOKEN_PATH, 'w') as tf:
                tf.write(creds.to_json())
            logging.info("Token refreshed. New expiry: %s", creds.expiry)
        
        youtube_service = build('youtube', 'v3', credentials=creds)
        return youtube_service
    except Exception as e:
        logging.error("Failed to authenticate YouTube service: %s", e)
        return None

def get_stream_status(youtube, stream_id: str) -> str:
    """Check ingestion status."""
    try:
        resp = youtube.liveStreams().list(part='status', id=stream_id).execute()
        items = resp.get('items', [])
        if not items:
            return 'unknown_stream_id'
        return items[0]['status'].get('streamStatus', 'unknown')
    except Exception as e:
        logging.error("Error getting stream status for %s: %s", stream_id, e)
        return 'error'

def get_broadcast_status_by_stream(youtube, stream_id: str) -> str:
    """Check broadcast lifecycle."""
    try:
        page_token = None
        while True:
            resp = youtube.liveBroadcasts().list(
                part='status,contentDetails', mine=True, maxResults=50, pageToken=page_token
            ).execute()
            for bc in resp.get('items', []):
                if bc.get('contentDetails', {}).get('boundStreamId') == stream_id:
                    return bc['status'].get('lifeCycleStatus', 'unknown')
            page_token = resp.get('nextPageToken')
            if not page_token:
                break
        return 'no_bound_broadcast'
    except Exception as e:
        logging.error("Error getting broadcast status for %s: %s", stream_id, e)
        return 'error'

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat(),
        'service': 'YouTube Stream Status API'
    })

@app.route('/stream-status/<stream_id>', methods=['GET'])
def check_single_stream(stream_id):
    """Check status of a single stream."""
    youtube = get_authenticated_service()
    if not youtube:
        return jsonify({
            'error': 'YouTube service not available',
            'isLive': False
        }), 500
    
    try:
        ingest_status = get_stream_status(youtube, stream_id)
        bc_status = get_broadcast_status_by_stream(youtube, stream_id)
        
        # Determine if stream is live
        is_live = (
            ingest_status.lower() == 'active' and 
            bc_status.lower() == 'live'
        )
        
        return jsonify({
            'streamId': stream_id,
            'isLive': is_live,
            'ingestionStatus': ingest_status,
            'broadcastStatus': bc_status,
            'timestamp': datetime.datetime.utcnow().isoformat()
        })
    
    except Exception as e:
        logging.error("Error checking stream %s: %s", stream_id, e)
        return jsonify({
            'error': str(e),
            'isLive': False,
            'streamId': stream_id
        }), 500

@app.route('/stream-status', methods=['POST'])
def check_stream_status():
    """Check status of a stream via POST request."""
    try:
        data = request.get_json()
        if not data or 'streamId' not in data:
            return jsonify({
                'error': 'streamId is required',
                'isLive': False
            }), 400
        
        stream_id = data['streamId']
        return check_single_stream(stream_id)
    
    except Exception as e:
        logging.error("Error processing POST request: %s", e)
        return jsonify({
            'error': str(e),
            'isLive': False
        }), 500

@app.route('/all-streams', methods=['GET'])
def check_all_streams():
    """Check status of all configured streams."""
    youtube = get_authenticated_service()
    if not youtube:
        return jsonify({
            'error': 'YouTube service not available',
            'streams': []
        }), 500
    
    if not os.path.isfile(CONFIG_PATH):
        return jsonify({
            'error': 'broadcasts.json not found',
            'streams': []
        }), 500
    
    broadcasts = load_broadcasts(CONFIG_PATH)
    results = []
    
    for stream_id, title in broadcasts.items():
        try:
            ingest_status = get_stream_status(youtube, stream_id)
            bc_status = get_broadcast_status_by_stream(youtube, stream_id)
            
            is_live = (
                ingest_status.lower() == 'active' and 
                bc_status.lower() == 'live'
            )
            
            results.append({
                'streamId': stream_id,
                'title': title,
                'isLive': is_live,
                'ingestionStatus': ingest_status,
                'broadcastStatus': bc_status
            })
        
        except Exception as e:
            logging.error("Error checking stream %s: %s", stream_id, e)
            results.append({
                'streamId': stream_id,
                'title': title,
                'isLive': False,
                'error': str(e)
            })
    
    return jsonify({
        'streams': results,
        'timestamp': datetime.datetime.utcnow().isoformat(),
        'total': len(results)
    })

if __name__ == '__main__':
    # Check for required files on startup
    if not os.path.isfile(TOKEN_PATH):
        logging.error("token.json not found. Please ensure YouTube API credentials are set up.")
        sys.exit(1)
    
    # Test YouTube service on startup
    youtube = get_authenticated_service()
    if not youtube:
        logging.error("Failed to initialize YouTube service. Check your credentials.")
        sys.exit(1)
    
    logging.info("YouTube Stream Status API starting...")
    logging.info("Available endpoints:")
    logging.info("  GET  /health - Health check")
    logging.info("  GET  /stream-status/<stream_id> - Check single stream")
    logging.info("  POST /stream-status - Check single stream (JSON body)")
    logging.info("  GET  /all-streams - Check all configured streams")
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=False)