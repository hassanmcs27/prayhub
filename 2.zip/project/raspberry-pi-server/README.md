# Raspberry Pi YouTube API Server

This Flask application runs on your Raspberry Pi and provides a REST API for checking YouTube stream status using your existing Python script logic.

## Features

- **REST API endpoints** for checking stream status
- **CORS enabled** for web browser requests
- **Systemd service** for automatic startup
- **Health check endpoint** for monitoring
- **Batch checking** of all configured streams
- **Error handling** and logging

## Setup Instructions

### 1. Copy Files to Raspberry Pi

Copy all files from the `raspberry-pi-server` directory to your Raspberry Pi:

```bash
scp -r raspberry-pi-server/ pi@your-pi-ip:~/youtube-api-server/
```

### 2. Run Setup Script

SSH into your Raspberry Pi and run the setup:

```bash
ssh pi@your-pi-ip
cd ~/youtube-api-server
chmod +x setup.sh
./setup.sh
```

### 3. Add Your Credentials

Copy your existing `token.json` file to the server directory:

```bash
cp /path/to/your/token.json ~/youtube-api-server/
```

### 4. Configure Streams

Edit `broadcasts.json` to match your actual stream IDs:

```bash
nano ~/youtube-api-server/broadcasts.json
```

### 5. Start the Service

```bash
sudo systemctl start youtube-api
sudo systemctl status youtube-api
```

## API Endpoints

### Health Check
```
GET http://your-pi-ip:5000/health
```

### Check Single Stream
```
GET http://your-pi-ip:5000/stream-status/YOUR_STREAM_ID
```

### Check Single Stream (POST)
```
POST http://your-pi-ip:5000/stream-status
Content-Type: application/json

{
  "streamId": "YOUR_STREAM_ID"
}
```

### Check All Streams
```
GET http://your-pi-ip:5000/all-streams
```

## Response Format

```json
{
  "streamId": "your-stream-id",
  "isLive": true,
  "ingestionStatus": "active",
  "broadcastStatus": "live",
  "timestamp": "2025-01-07T10:30:00.000Z"
}
```

## Monitoring

### View Logs
```bash
sudo journalctl -u youtube-api -f
```

### Check Service Status
```bash
sudo systemctl status youtube-api
```

### Restart Service
```bash
sudo systemctl restart youtube-api
```

## Firewall Configuration

If you have a firewall enabled, allow port 5000:

```bash
sudo ufw allow 5000
```

## Network Configuration

Make sure your Raspberry Pi has a static IP address or use dynamic DNS for reliable access from your website.

## Security Considerations

- The API runs on port 5000 by default
- Consider using HTTPS in production
- Restrict access to your local network if possible
- Keep your `token.json` file secure

## Troubleshooting

### Service Won't Start
1. Check logs: `sudo journalctl -u youtube-api -f`
2. Verify `token.json` exists and is valid
3. Check Python dependencies: `source youtube_api_env/bin/activate && pip list`

### API Not Accessible
1. Check if service is running: `sudo systemctl status youtube-api`
2. Verify firewall settings: `sudo ufw status`
3. Test locally: `curl http://localhost:5000/health`

### Authentication Errors
1. Refresh your `token.json` by running your original Python script
2. Check token expiry in the logs
3. Verify YouTube API quotas in Google Cloud Console